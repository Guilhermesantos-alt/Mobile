package br.com.devconnect.olxsenai.model;

public @interface Exclude {
}
